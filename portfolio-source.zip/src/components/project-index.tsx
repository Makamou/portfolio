import { useState } from "react";
import { ArrowUpRight, X } from "lucide-react";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { collection, type Category, type Project } from "@/data/projects";

const asset = (path: string) => `${import.meta.env.BASE_URL}${path}`;

const filters: ("All" | Category)[] = ["All", "Business website", "Application", "Interface demo", "Game", "Concept"];

export function ProjectIndex() {
  const [filter, setFilter] = useState<(typeof filters)[number]>("All");
  const [open, setOpen] = useState<Project | null>(null);
  const visible = filter === "All" ? collection : collection.filter((project) => project.category === filter);

  return (
    <section id="index" className="py-24">
      <div className="mb-14 flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <h2 className="kicker">02 / Archive index</h2>
        <div className="flex flex-wrap gap-x-6 gap-y-2 text-[0.7rem] font-bold uppercase tracking-[0.18em]">
          {filters.map((item) => (
            <button
              key={item}
              type="button"
              aria-pressed={filter === item}
              onClick={() => setFilter(item)}
              className={`transition-colors ${filter === item ? "text-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      <div key={filter} className="filter-results border-t border-line">
        {visible.map((project, index) => (
          <button
            key={project.slug}
            type="button"
            onClick={() => setOpen(project)}
            className="project-row group w-full cursor-crosshair border-b border-line-faint px-2 py-6 text-left transition-colors hover:bg-foreground/[0.04]"
          >
            <span className="font-mono text-xs text-muted-foreground transition-colors group-hover:text-foreground">{String(index + 1).padStart(3, "0")}</span>
            <span className="truncate text-lg font-bold">{project.title}</span>
            <span className="hidden font-mono text-xs text-muted-foreground sm:block">{project.category}</span>
            <ArrowUpRight size={16} className="justify-self-end text-muted-foreground transition-colors group-hover:text-foreground" />
          </button>
        ))}
      </div>

      <Dialog open={Boolean(open)} onOpenChange={(next) => !next && setOpen(null)}>
        <DialogContent className="max-h-[90dvh] max-w-2xl overflow-y-auto rounded-none border-line bg-card p-8 text-card-foreground">
          <DialogClose className="absolute right-5 top-5 text-muted-foreground hover:text-foreground" aria-label="Close project"><X size={18} /></DialogClose>
          {open && (
            <>
              <span className="kicker block">{open.category}</span>
              {open.image && <img src={asset(open.image)} alt={`${open.title} screenshot`} className="mt-5 max-h-72 w-full object-contain object-top" />}
              <DialogTitle className="mt-3 text-4xl font-bold tracking-tight uppercase">{open.title}</DialogTitle>
              <DialogDescription className="mt-4 text-base leading-relaxed text-soft">{open.detail || open.summary}</DialogDescription>
              {open.tech && <div className="mt-4 flex flex-wrap gap-2">{open.tech.map(t => <span key={t} className="border border-line px-2 py-1 text-xs">{t}</span>)}</div>}
              {open.url ? (
                <a href={open.url} target="_blank" rel="noreferrer" className="mt-6 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-foreground underline underline-offset-4">
                  Visit project <ArrowUpRight size={15} />
                </a>
              ) : (
                <span className="mt-6 inline-block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Public demo not available</span>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
