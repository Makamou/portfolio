import { useEffect, useRef, type ReactNode } from 'react';

// Content stays visible until progressive enhancement attaches successfully.
export function PortfolioMotion({ children }: { children: ReactNode }) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!root.current || typeof IntersectionObserver === 'undefined') return;
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (preference.matches) return;
    const elements = Array.from(root.current.querySelectorAll<HTMLElement>('[data-reveal]'));
    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) if (entry.isIntersecting) {
        entry.target.classList.remove('motion-pending');
        observer.unobserve(entry.target);
      }
    }, { threshold: 0.08, rootMargin: '0px 0px 30px 0px' });
    elements.forEach(element => {
      element.classList.add('motion-pending');
      observer.observe(element);
    });
    const revealAll = () => {
      if (preference.matches) {
        observer.disconnect();
        elements.forEach(element => element.classList.remove('motion-pending'));
      }
    };
    preference.addEventListener('change', revealAll);
    return () => {
      observer.disconnect();
      preference.removeEventListener('change', revealAll);
      elements.forEach(element => element.classList.remove('motion-pending'));
    };
  }, []);
  return <div ref={root}>{children}</div>;
}
