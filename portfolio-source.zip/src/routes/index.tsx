import { createFileRoute } from "@tanstack/react-router";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { PortfolioMotion } from "@/components/portfolio-motion";
import { ProjectIndex } from "@/components/project-index";
import { building, contact, featured, skills } from "@/data/projects";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Moubarak Akamou — Software Developer, Dallas–Fort Worth" },
      { name: "description", content: "Portfolio of Moubarak Akamou: web applications, responsive interfaces and business websites. English & French." },
      { property: "og:title", content: "Moubarak Akamou — Software Developer" },
      { property: "og:description", content: "Web applications, responsive interfaces and business websites from Dallas–Fort Worth." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const asset = (path: string) => `${import.meta.env.BASE_URL}${path}`;

function Nav() {
  const links: [string, string][] = [
    ["Projects", "#work"],
    ["Index", "#index"],
    ["Building", "#building"],
    ["About", "#about"],
  ];
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-background/80 backdrop-blur-md">
      <nav aria-label="Primary" className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:px-6">
        <a href="#top" className="flex items-baseline gap-2">
          <span className="text-lg font-bold tracking-tighter">MOUBARAK AKAMOU</span>
          <span className="pill border-line text-muted-foreground">©26</span>
        </a>
        <div className="hidden items-center gap-8 text-[0.8rem] font-medium uppercase tracking-[0.18em] md:flex">
          {links.map(([label, href]) => (
            <a key={href} href={href} className="transition-colors text-soft hover:text-foreground">{label}</a>
          ))}
          <a href="#contact" className="text-foreground">Contact</a>
        </div>
        <span className="font-mono text-xs text-muted-foreground" aria-label="Speaks English and French">EN / FR</span>
      </nav>
      <nav aria-label="Mobile navigation" className="flex justify-center gap-4 border-t border-line px-3 py-3 text-xs md:hidden">{links.map(([label, href]) => <a key={href} href={href}>{label}</a>)}<a href="#contact">Contact</a></nav>
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="hero-motion relative overflow-hidden border-b border-line-faint px-5 py-32 md:px-6 md:py-52">
      <div className="pointer-events-none absolute left-1/2 top-1/2 w-full -translate-x-1/2 -translate-y-1/2 select-none text-center">
        <span className="display whitespace-nowrap text-[22vw] uppercase italic text-foreground/[0.035]">Moubarak</span>
      </div>
      <div className="relative z-10 mx-auto max-w-7xl">
        <p className="kicker mb-8">— Moubarak Akamou / Software developer / Dallas–Fort Worth</p>
        <h1 className="max-w-5xl text-5xl font-bold leading-[0.95] tracking-tighter md:text-8xl">
          Building <span className="bg-gradient-to-r from-foreground via-foreground/55 to-foreground/15 bg-clip-text text-transparent">web applications</span>, interfaces and business sites with architectural precision.
        </h1>
        <p className="mt-12 max-w-xl text-lg leading-relaxed text-soft">
          I’m Moubarak Akamou, a bilingual software developer building useful, clear digital products in English and French — from concept to deployment.
        </p>
        <div className="mt-16 flex items-center justify-between border-t border-line pt-4">
          <span className="kicker">Selected work below</span>
          <a href="#work" aria-label="Jump to selected work" className="flex h-11 w-11 items-center justify-center border border-line text-foreground transition-colors hover:bg-foreground hover:text-background">
            <ArrowDown size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}

function SectionHeading({ num, title }: { num: string; title: string }) {
  return (
    <div className="mb-12 flex items-end justify-between gap-8">
      <h2 className="kicker whitespace-nowrap">{num} / {title}</h2>
      <div className="h-px flex-grow bg-line" aria-hidden="true" />
    </div>
  );
}

function Featured() {
  return (
    <section id="work" className="px-5 py-24 md:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeading num="01" title="Featured projects" />
        <div className="grid border border-line md:grid-cols-3">
          {featured.map((project, index) => (
            <a
              key={project.slug}
              data-reveal
              href={project.url ?? "#index"}
              target={project.url ? "_blank" : undefined}
              rel="noreferrer"
              className={`project-cell featured-cell group min-h-[380px] ${index < 2 ? "border-b border-line md:border-b-0 md:border-r" : ""}`}
            >
              <div className="flex items-start justify-between">
                <span className="font-mono text-xs">[{String(index + 1).padStart(2, "0")}]</span>
                <span className="pill">{project.category}</span>
              </div>
              <div>
                <div className={`featured-media ${project.image ? "" : "featured-media-empty"}`} aria-hidden={project.image ? undefined : true}>
                  {project.image && <img src={asset(project.image)} alt={`${project.title} screenshot`} className="h-full w-full object-cover object-top" loading="lazy" width={1200} height={750} />}
                </div>
                <h3 className="text-3xl font-bold tracking-tight">{project.title}</h3>
                <p className="mt-4 text-sm leading-relaxed text-soft group-hover:text-current group-hover:opacity-70">{project.summary}</p>
                <div className="mt-8 flex flex-wrap items-center gap-x-2 gap-y-1">
                  {(project.contribution ?? []).slice(0, 3).map((item, i) => (
                    <span key={item} className="chip flex items-center gap-2">
                      {i > 0 && <span className="accent-dot" aria-hidden="true">•</span>}{item}
                    </span>
                  ))}
                  <ArrowUpRight size={16} className="ml-auto transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function Building() {
  return (
    <section id="building" className="px-5 py-24 md:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeading num="03" title="On the bench" />
        <div className="grid border border-line md:grid-cols-2">
          {building.map((item, index) => (
            <article key={item.title} className={`min-h-64 p-8 md:p-10 ${index ? "border-t border-line md:border-l md:border-t-0" : ""}`}>
              <span className="chip accent-dot">{item.status}</span>
              <h3 className="mt-14 text-2xl font-bold tracking-tight">{item.title}</h3>
              <p className="mt-4 max-w-lg text-sm leading-relaxed text-soft">{item.body}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function SkillList({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <span className="kicker block">{title}</span>
      <ul className="mt-4 border-t border-line">
        {items.map((item) => <li key={item} className="border-b border-line py-2 text-sm font-medium">{item}</li>)}
      </ul>
    </div>
  );
}

function About() {
  return (
    <section id="about" className="px-5 py-24 md:px-6">
      <div className="mx-auto grid max-w-7xl gap-10 md:grid-cols-2 md:gap-16">
        <div>
          <SectionHeading num="04" title="About" />
          <p className="mt-2 max-w-xl text-2xl font-medium leading-snug">
            Bilingual developer based in Dallas–Fort Worth, focused on useful, clear digital products — web applications, responsive interfaces and business websites.
          </p>
          <div className="mt-12 grid grid-cols-2 gap-8">
            <SkillList title="Working with" items={skills.established} />
            <SkillList title="Learning" items={skills.learning} />
          </div>
        </div>
        <figure className="overflow-hidden border border-line bg-card">
          <img src={asset("images/myPicture.webp")} alt="Portrait of Moubarak Akamou" className="aspect-[4/5] w-full object-cover object-top grayscale" width={650} height={800} loading="lazy" />
          <figcaption className="border-t border-line p-6 text-sm leading-relaxed text-soft">Moubarak Akamou · Software Developer<br />Dallas–Fort Worth · English & French</figcaption>
        </figure>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <footer id="contact" className="border-t border-line px-5 py-40 text-center md:px-6">
      <p className="kicker mb-8">05 / Connection</p>
      <a href={`mailto:${contact.email}`} className="block break-words text-4xl font-bold tracking-tighter transition-transform duration-500 hover:translate-x-4 hover:italic md:text-7xl">
        {contact.email}
      </a>
      <div className="mt-24 flex justify-center gap-12 font-mono text-[10px] uppercase tracking-[0.2em]">
        <a href={contact.github} target="_blank" rel="noreferrer" className="transition-colors hover:text-primary">GitHub</a>
        <a href={`mailto:${contact.email}`} className="transition-colors hover:text-primary">Email</a>
      </div>
      <div className="mt-16 border-t border-line-faint pt-6 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
        © 2026 Moubarak Akamou · Dallas–Fort Worth, Texas
      </div>
    </footer>
  );
}

export function Index() {
  return (
    <PortfolioMotion>
      <a href="#work" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:bg-foreground focus:p-3 focus:text-background">Skip to work</a>
      <Nav />
      <main className="mx-auto max-w-7xl px-5 md:px-6">
        <Hero />
        <Featured />
        <ProjectIndex />
        <Building />
        <About />
      </main>
      <Contact />
    </PortfolioMotion>
  );
}
