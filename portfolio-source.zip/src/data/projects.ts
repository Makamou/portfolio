// Portfolio content and supplied assets. Paths remain relative to the hosting base.
export type Category = "Business website" | "Application" | "Interface demo" | "Game" | "Concept";
export interface Project { slug: string; title: string; category: Category; summary: string; detail?: string; contribution?: string[]; tech?: string[]; url?: string; image?: string; }
export const featured: Project[] = [
  {
    "slug": "quranroots",
    "title": "QuranRoots",
    "category": "Application",
    "summary": "An English and French Quran reading and learning experience.",
    "detail": "Reading, structured lessons, and progress tracking in one bilingual experience. Work includes interface improvements, production validation, security headers, and deployment workflows.",
    "tech": [
      "Cloudflare Workers",
      "Supabase",
      "EN / FR"
    ],
    "image": "images/quranroots.webp",
    "url": "https://quranroots.vertexone.workers.dev",
    "contribution": [
      "Bilingual interface",
      "Structured lessons and progress tracking",
      "Production validation and deployment workflows"
    ]
  },
  {
    "slug": "assure-coaching",
    "title": "Assure Coaching",
    "category": "Business website",
    "summary": "A cohesive web experience for a coaching business.",
    "detail": "A redesign focused on clear content, responsive layouts, and consistent design across pages, including the blog experience.",
    "tech": [
      "Responsive design",
      "Content architecture"
    ],
    "url": "https://makamou.github.io/assure-coaching/",
    "contribution": [
      "Content structure",
      "Responsive layouts",
      "Cross-page consistency"
    ]
  },
  {
    "slug": "chez-christian",
    "title": "Chez Christian",
    "category": "Application",
    "summary": "Turn ingredients into ideas for your next meal.",
    "detail": "An AI recipe application that helps users explore meals based on the ingredients they have available.",
    "tech": [
      "AI",
      "Recipe generation"
    ],
    "image": "images/chefChristian.webp",
    "url": "https://chef-christian.vercel.app/",
    "contribution": [
      "Ingredient-based recipe discovery",
      "AI-assisted suggestions"
    ]
  }
];
export const collection: Project[] = [
  {
    "slug": "shalom-enterprise",
    "title": "Shalom Enterprise",
    "category": "Business website",
    "summary": "A polished digital presence for a limousine service.",
    "detail": "A transport business website built around service discovery and reservations. The supplied portfolio describes an EmailJS reservation integration.",
    "tech": [
      "Business website",
      "Reservations"
    ],
    "image": "images/shalomEntreprise.webp",
    "url": "https://shalomtransit.com/"
  },
  {
    "slug": "humble-delicacies",
    "title": "Humble Delicacies",
    "category": "Business website",
    "summary": "A warm, distinctive website for an artisanal bakery.",
    "detail": "A bakery website presenting its products and brand, with ordering and delivery information described in the original portfolio.",
    "tech": [
      "Bakery",
      "Brand experience"
    ],
    "image": "images/humbleDelicacies.webp",
    "url": "https://humbledelicacies.netlify.app/"
  },
  {
    "slug": "vivid-space-media",
    "title": "Vivid Space Media",
    "category": "Business website",
    "summary": "Give real estate photography room to speak.",
    "detail": "A property photography portfolio designed around image presentation, service information, and an approachable brand experience.",
    "tech": [
      "Photography",
      "Portfolio"
    ],
    "image": "images/vividSpaces.webp",
    "url": "https://makamou.github.io/vividspacemedia/"
  },
  {
    "slug": "petite-focus",
    "title": "Petite Focus",
    "category": "Business website",
    "summary": "A visual home for photographic storytelling.",
    "detail": "A photography portfolio that uses imagery and a restrained interface to showcase visual work.",
    "tech": [
      "Photography",
      "Visual storytelling"
    ],
    "image": "images/petiteFocus.webp",
    "url": "https://makamou.github.io/petite-focus/index.html"
  },
  {
    "slug": "olabank-dashboard",
    "title": "OlaBank Dashboard",
    "category": "Interface demo",
    "summary": "Explore a banking dashboard through a focused interface.",
    "detail": "A banking dashboard interface project exploring financial information, visual hierarchy, and account controls. Presented as a portfolio interface, not a banking service.",
    "tech": [
      "FinTech interface",
      "UI / UX"
    ],
    "image": "images/olaBank.webp",
    "url": "https://makamou.github.io/olabank/"
  },
  {
    "slug": "ayoflow",
    "title": "AyoFlow",
    "category": "Application",
    "summary": "A simple interface for organizing everyday tasks.",
    "detail": "A task management application exploring task organization and a streamlined productivity interface.",
    "tech": [
      "Productivity",
      "Interface design"
    ],
    "image": "images/ayoFlow.webp",
    "url": "https://makamou.github.io/AyoFlow/"
  },
  {
    "slug": "langguesser",
    "title": "LangGuesser",
    "category": "Game",
    "summary": "A programming language twist on Hangman.",
    "detail": "An interactive guessing game that uses programming language names as its theme, with a React interface and keyboard-style controls.",
    "tech": [
      "React",
      "Game interactions"
    ],
    "image": "images/langGuesser.webp",
    "url": "https://lang-guesser.vercel.app/"
  },
  {
    "slug": "guess-game",
    "title": "Guess Game",
    "category": "Game",
    "summary": "Find the secret number, one guess at a time.",
    "detail": "A number guessing game exploring user input, feedback, scoring, and interactive game logic.",
    "tech": [
      "Game logic",
      "Interactive UI"
    ],
    "image": "images/GuessNumber.webp",
    "url": "https://makamou.github.io/guessNumber/"
  },
  {
    "slug": "pig-game",
    "title": "Pig Game",
    "category": "Game",
    "summary": "A turn-based game of risk and reward.",
    "detail": "A dice game centered on turn-taking, accumulating points, and choosing when to hold a score.",
    "tech": [
      "State management",
      "Game logic"
    ],
    "image": "images/pigGame.webp",
    "url": "https://makamou.github.io/my-pig-game/"
  },
  {
    "slug": "rock-paper-scissors",
    "title": "Rock Paper Scissors",
    "category": "Game",
    "summary": "A familiar game with a playful digital interface.",
    "detail": "A browser game built around player choices, computer responses, and outcome feedback.",
    "tech": [
      "Game interactions",
      "UI design"
    ],
    "image": "images/rockpper.webp",
    "url": "https://makamou.github.io/RockPaperScissor/"
  },
  {
    "slug": "ubuntu-diaspora",
    "title": "Ubuntu Diaspora",
    "category": "Concept",
    "summary": "A community platform connecting the African diaspora.",
    "detail": "A community platform connecting the African diaspora, with a focus on a shared digital community.",
    "tech": [
      "Community",
      "Platform concept"
    ],
    "image": "images/ubuntu.webp",
    "url": "https://ubuntu-diaspora.vercel.app/"
  },
  {
    "slug": "vertex-studio",
    "title": "Vertex One Studio",
    "category": "Business website",
    "summary": "A branded showcase for digital design and development.",
    "detail": "The original studio website supplied with this portfolio. It presents services, project categories, contact information, and a visual brand system.",
    "tech": [
      "HTML",
      "CSS",
      "JavaScript"
    ],
    "image": "images/about_pic.webp",
    "url": "https://moubarakakamou.com/"
  }
];
export const building = [
  {
    "title": "MediaVertex One",
    "status": "In development",
    "body": "A portfolio and learning project progressing from Docker and Nginx toward a full media platform. The planned architecture includes React, Django REST, PostgreSQL, Redis, Celery, object storage, FFmpeg, and HLS. These are planned capabilities, not a completed production stack."
  },
  {
    "title": "ReadyOps",
    "status": "Concept & design",
    "body": "An application concept developed through problem research and an initial interface direction. Product discovery and design are the current stage."
  }
];
export const skills = { established: ["HTML", "CSS", "JavaScript", "React", "Node.js", "Responsive design", "Git & GitHub"], learning: ["Linux", "Docker", "Nginx", "Cloud technologies"] };
export const contact = {email: "amkristian91@gmail.com", github: "https://github.com/makamou"};
