import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import { describe, it, expect, afterEach } from 'vitest';
import { Index } from '@/routes/index';
import { featured, collection, building } from '@/data/projects';
afterEach(cleanup);
describe('Portfolio asset integration', () => {
 it('preserves all 17 projects and supplied images', () => {
  expect(featured.length + collection.length + building.length).toBe(17);
  expect(featured[0]!.image).toBe('images/quranroots.webp');
  expect(collection.every(p => p.image)).toBe(true);
  expect(collection.find(p => p.title === 'Ubuntu Diaspora')?.url).toBe('https://ubuntu-diaspora.vercel.app/');
  expect(collection.find(p => p.title === 'Vertex One Studio')?.url).toBe('https://moubarakakamou.com/');
 });
 it('shows portrait, filters games, and opens details with image and link', () => {
  render(<Index />);
  expect(screen.getByAltText('Portrait of Moubarak Akamou').getAttribute('src')).toContain('images/myPicture.webp');
  fireEvent.click(screen.getByRole('button', { name: 'Game' }));
  expect(screen.queryByRole('button', { name: /Shalom Enterprise/ })).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: /LangGuesser/ }));
  expect(screen.getByRole('dialog')).toBeTruthy();
  expect(screen.getByAltText('LangGuesser screenshot').getAttribute('src')).toContain('langGuesser.webp');
  expect(screen.getByRole('link', { name: 'Visit project' }).getAttribute('href')).toBe('https://lang-guesser.vercel.app/');
  fireEvent.click(screen.getByRole('button', { name: 'Close project' }));
  expect(screen.queryByRole('dialog')).toBeNull();
 });
});
