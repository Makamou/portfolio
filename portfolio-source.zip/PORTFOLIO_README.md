# Moubarak Akamou — Lovable Portfolio

The Lovable dark architectural design is preserved, with the supplied portrait, project images, descriptions, technologies and links integrated. All 17 projects are retained.

## Upload to your GitHub portfolio repository
Open the github-pages folder in this archive and upload its CONTENTS to your repository root. index.html, assets, images, brand, favicon.ico and robots.txt must sit at the root, not inside a github-pages folder. Preserve .nojekyll if you deploy using Git. Configure Pages to deploy from main and /(root).

## Preview on your Mac
In the github-pages folder run:

    python3 -m http.server 8081

Open http://localhost:8081.

## Editable Lovable source
The source folder contains the updated React/TanStack project and supplied assets.

    npm ci
    npm run dev

For the independent static version:

    npm run dev:pages
    npm run build:pages

The static output appears in dist-pages. Relative URLs support /portfolio/ and other folder paths. The original Lovable build remains available via npm run build.

## Content updates
src/data/projects.ts contains project descriptions, links, images, skills and work-in-progress status. public/images contains supplied portrait and screenshots. public/brand contains supplied SVG logos.

## Missing images
No Assure Coaching screenshot was supplied; its intentional typographic presentation remains. No screenshots were supplied for MediaVertex One or ReadyOps; their development sections stay text-based. Ubuntu Diaspora and Vertex One Studio now include the public URLs supplied by the owner.

## Checks
Production builds, TypeScript checks, project filters, modal opening/closing and supplied image references were checked. External project availability was not independently verified.
