import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { fileURLToPath, URL } from 'node:url';
import { renameSync } from 'node:fs';
// Standalone static build: same React components, no server required.
export default defineConfig({
  base: './',
  plugins: [react(), tailwindcss(), { name: 'pages-index', closeBundle() { renameSync('dist-pages/pages.html', 'dist-pages/index.html'); } }],
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
  build: { outDir: 'dist-pages', emptyOutDir: true, rolldownOptions: { input: 'pages.html' } },
});
